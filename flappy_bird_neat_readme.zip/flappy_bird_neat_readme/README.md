# 🐦 Flappy Bird AI Using NEAT

<p align="center">
  <img src="assets/readme-banner.png" alt="Flappy Bird AI banner" width="100%">
</p>

<p align="center">
  <b>Training an AI to play Flappy Bird using NeuroEvolution of Augmenting Topologies (NEAT).</b>
</p>

![Python](https://img.shields.io/badge/Python-3.x-blue?logo=python)
![AI](https://img.shields.io/badge/AI-NEAT-purple)
![Game](https://img.shields.io/badge/Game-Pygame-green)

## 📌 About
This project uses the **NEAT algorithm** to evolve neural networks that learn to play Flappy Bird automatically. The AI observes the bird and nearby pipes, decides when to flap, and improves through generations using fitness-based evolution.

## 🖼️ How NEAT Learns
<p align="center">
  <img src="assets/neat-workflow.png" alt="NEAT AI learning workflow" width="100%">
</p>

## 🛠️ Tech Stack
- **Python** — programming language
- **Pygame** — game simulation
- **NEAT-Python** — evolving neural networks

## 🚀 Setup
Install the dependencies:

```bash
pip install pygame neat-python
```

Run the project (if `main.py` is your entry point):

```bash
python main.py
```

## ✨ Features
- AI-controlled gameplay
- Neural network evolution across generations
- Fitness-based selection and mutation
- Automatic pipe avoidance

## 🎯 Goal
Demonstrate how evolutionary algorithms can train an AI agent to make decisions and improve its performance over time.

## 📚 References
- [NEAT-Python Documentation](https://neat-python.readthedocs.io/en/latest/)

---
**Made with Python and NEAT 🧠🐦**
